# Generated Equations Should Be In LaTeX/Equations

This directory exists to allow the documents to compile without the use
of the latexmk tool, but full and correct reproduction of the results
should use latexmkrc, which requires some specific configuration for
each computer system:

[latexmk](https://mg.readthedocs.io/latexmk.htm)
