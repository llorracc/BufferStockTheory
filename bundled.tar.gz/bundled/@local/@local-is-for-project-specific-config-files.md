# @local directory is where to put detailed configurations

  Some project have large numbers of configurations to set
  - this is for those
  - @resources is for material obtained elsewhere
  