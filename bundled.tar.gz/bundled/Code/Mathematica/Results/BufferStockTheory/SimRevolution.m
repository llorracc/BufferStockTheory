(* ::Package:: *)

Print["Running SimRevolution.m"];
pRattList[[-1]] = Table[1,{Length[pRattList[[-1]]]}];
pLevtList[[-1]] = Table[pLevtMean[[-1]], {Length[pLevtList[[-1]]]}];

KeepSimulating[21];

