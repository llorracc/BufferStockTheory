The key file in this directory is the notebook

  doAll.nb

which successively constructs all of the figures used in the main body of the paper.  

The next most important files are

  doAppndxLiqConstr.nb 
  doAppndxcLim.nb

which produces results for the appendix.  

The remaining files are used by these master files to produce specific results.

