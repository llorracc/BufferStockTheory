
./CoreCode contains general purpose algorithms for solving and simulating a buffer stock
model of the kind described in the paper "Theoretical Foundations of Buffer Stock Saving"

The best starting place for understanding the model is probably the file "DefineSolutionLoop.m" 
which should be opened using the Mathematica package editor.


