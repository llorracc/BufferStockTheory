#!/bin/bash

# sentence it

/Volumes/Data/Papers/BufferStockTheory/BufferStockTheory-Latest/@resources/bash/split-to-sentences-all-tex-files.sh --all --replace /Volumes/Data/Papers/BufferStockTheory/BufferStockTheory-Latest

/Volumes/Data/Papers/BufferStockTheory/BufferStockTheory-Latest/@resources/bash/split-to-sentences-all-tex-files.sh --all --replace /Volumes/Data/Papers/BufferStockTheory/BufferStockTheory-Latest/Appendices

