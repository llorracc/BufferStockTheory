#!/bin/bash

# clone contents of -Latest to -Public
